#ifndef POSTS_H
#define POSTS_H


/**
 * Function that handles the calling of every command from task 2
 *
 * Please add any necessary parameters to the functions
*/
//const int nod_max = 500;
void handle_input_posts(char *input, post_t **posts, int *nrp);

#endif // POSTS_H
