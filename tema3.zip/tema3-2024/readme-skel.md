## Echipa tema 3 SD: 
    Constantin Dimitrie 315CA
    Dinca Aelius-Gabriel 315CA

## Titlu + numar temă
    Tema 3 - Social media de buget
### Descriere:
    

### Comentarii asupra temei:

* Crezi că ai fi putut realiza o implementare mai bună?
* Ce ai invățat din realizarea acestei teme?
* Alte comentarii

### (Opțional) Resurse / Bibliografie:

1. [Așa se adaugă un link în Markdown](https://youtu.be/dQw4w9WgXcQ)

PS: OCW strică link-ul, trebuie să puneți ***doar*** https-ul intre ().
